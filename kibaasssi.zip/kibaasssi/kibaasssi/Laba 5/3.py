while True:
    user_input = input("Введите целые числа (для завершения введите 'q'): ")
    total = 0
    digits = ""

    for char in user_input:
        if char.isdigit():
            digits += char

    if digits:
        total = sum(int(digit) for digit in digits)
        print("Сумма введенных цифр:", total)
        break
    else:
        print("Вы не ввели цифры. Повторите ввод.")