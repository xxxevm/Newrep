def read_matrix(file_name):
    try:
        with open(file_name, "r") as file:
            matrix = []
            for line in file:
                row = list(map(int, line.strip().split()))
                matrix.append(row)
            return matrix
    except FileNotFoundError:
        print("Файл не найден.")
        return None
    except Exception as e:
        print("Ошибка при чтении файла:", e)
        return None

def multiply_matrices(matrix1, matrix2):
    if len(matrix1[0]) != len(matrix2):
        print("Невозможно умножить матрицы: неправильные размеры.")
        return None

    result = []
    for i in range(len(matrix1)):
        row = []
        for j in range(len(matrix2[0])):
            element = 0
            for k in range(len(matrix2)):
                element += matrix1[i][k] * matrix2[k][j]
            row.append(element)
        result.append(row)
    return result

def print_matrix(matrix1, matrix2, product):
    for i in range(len(matrix1)):
        for el in matrix1[i]:
            print(el, end=" ")
        if i == (len(matrix1) // 2):
            print('\tX\t', end=" ")
        else:
            print('\t\t', end=" ")
        for el in matrix2[i]:
            print(el, end=" ")
        if i == (len(matrix1) // 2):
            print('\t=\t', end=" ")
        else:
            print('\t\t', end=" ")
        for el in product[i]:
            print(el, end=" ")
        print()

matrix1_file = "matrix1.txt"
matrix2_file = "matrix2.txt"

matrix1 = read_matrix(matrix1_file)
matrix2 = read_matrix(matrix2_file)

product = multiply_matrices(matrix1, matrix2)

print_matrix(matrix1, matrix2, product)