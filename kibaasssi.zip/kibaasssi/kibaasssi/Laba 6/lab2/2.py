def write_data_to_file(data):
    with open("data.txt", "a") as file:
        file.write(data + "\n")

def read_data_from_file():
    try:
        with open("data.txt", "r") as file:
            data = file.readlines()
            return data
    except FileNotFoundError:
        print("Файл не найден.")
        return []
    except Exception as e:
        print("Ошибка при чтении файла:", e)
        return []

def update_file_with_stats(numbers):
    if numbers:
        try:
            with open("data.txt", "a") as file:
                file.write("Сумма: {}\n".format(sum(numbers)))
                file.write("Максимум: {}\n".format(max(numbers)))
                file.write("Минимум: {}\n".format(min(numbers)))
        except Exception as e:
            print("Ошибка при обновлении файла:", e)

while True:
    user_input = input("Введите любые символы (для выхода введите 'q'): ")
    if user_input.lower() == 'q':
        break
    else:
        write_data_to_file(user_input)

data_from_file = read_data_from_file()

if data_from_file:
    numbers = [float(line.strip()) for line in data_from_file if line.strip().replace('.', '', 1).isdigit()]
    update_file_with_stats(numbers)
    print("Данные успешно записаны и обновлены в файле.")
