def write_numbers_to_file(numbers):
    with open("numbers.txt", "w") as file:
        for number in numbers:
            file.write(str(number) + "\n")

def read_numbers_from_file():
    try:
        with open("numbers.txt", "r") as file:
            numbers = [float(line.strip()) for line in file.readlines()]
            return numbers
    except FileNotFoundError:
        print("Файл не найден.")
        return None
    except Exception as e:
        print("Ошибка при чтении файла:", e)
        return None

def update_file_with_stats(numbers):
    if numbers is None:
        return
    try:
        with open("numbers.txt", "a") as file:
            file.write("Сумма: {}\n".format(sum(numbers)))
            file.write("Максимум: {}\n".format(max(numbers)))
            file.write("Минимум: {}\n".format(min(numbers)))
    except Exception as e:
        print("Ошибка при обновлении файла:", e)
numbers = input("Введите числа через пробел: ").split()
numbers = [float(num) for num in numbers]
write_numbers_to_file(numbers)
numbers_from_file = read_numbers_from_file()
if numbers_from_file is not None:
    update_file_with_stats(numbers_from_file)
    print("Данные успешно записаны и обновлены в файле.")
