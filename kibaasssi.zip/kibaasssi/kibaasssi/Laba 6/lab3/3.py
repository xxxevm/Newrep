def read_seat_status(file_name):
    try:
        with open(file_name, "r") as file:
            seat_status = [list(map(int, line.strip().split())) for line in file.readlines()]
            return seat_status
    except FileNotFoundError:
        print("Файл не найден.")
        return []
    except Exception as e:
        print("Ошибка при чтении файла:", e)
        return []

def count_free_seats(seat_status):
    total_seats = 0
    free_seats = 0
    free_seats_per_row = []

    for row in seat_status:
        total_seats += len(row)
        free_seats_per_row.append(row.count(0))
        free_seats += row.count(0)

    return total_seats, free_seats, free_seats_per_row

def is_seat_free(seat_status, row, seat):
    try:
        return seat_status[row - 1][seat - 1] == 0
    except IndexError:
        print("Указаны недопустимые значения ряда или места.")
        return False

file_name = "cinema_seats.txt"
seat_status = read_seat_status(file_name)
total_seats, free_seats, free_seats_per_row = count_free_seats(seat_status)
print("Общее количество мест в зале:", total_seats)
print("Количество свободных мест в зале:", free_seats)
print("Количество свободных мест в каждом ряду:", free_seats_per_row)

while True:
    try:
        row = int(input("Введите номер ряда (1-{}): ".format(len(seat_status))))
        seat = int(input("Введите номер места (1-{}): ".format(len(seat_status[row - 1]))))
        if is_seat_free(seat_status, row, seat):
            print("Место свободно.")
        else:
            print("Место занято.")
    except ValueError:
        print("Номер ряда и места должны быть целыми числами.")
    except KeyboardInterrupt:
        print("\nПрограмма завершена.")
        break

