import os

def find_file_by_name(file_name, search_path):
    for root, dirs, files in os.walk(search_path):
        if file_name in files:
            return os.path.join(root, file_name)
    return None

file_name = "lab5.py"
search_path = "C:\\"

file_path = find_file_by_name(file_name, search_path)

if file_path is not None:
    print("Файл найден по следующему пути:")
    print(file_path)
else:
    print("Файл с именем", file_name, "не найден.")

