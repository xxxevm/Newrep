s1 = input()
s2 = input()
try:
    print(int(s1) + int(s2))
except:
    print(s1 + s2)