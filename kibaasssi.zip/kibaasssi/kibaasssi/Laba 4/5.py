def move_disk(from_pole, to_pole):
    print("Move disk from", from_pole, "to", to_pole)

def hanoi�Rec(n, from_pole, to_pole, aux_pole):
    if n == 1:
        move_disk(from_pole, to_pole)
    else:
        hanoi�Rec(n-1, from_pole, aux_pole, to_pole)
        move_disk(from_pole, to_pole)
        hanoi�Rec(n-1, aux_pole, to_pole, from_pole)

def hanoiCicl(n, from_pole, to_pole, aux_pole):
    poles = [(from_pole, to_pole), (aux_pole, to_pole)]
    while n > 0:
        for src, dest in poles:
            if n == 1:
                move_disk(src, dest)
            else:
                move_disk(src, aux_pole)
                n -= 1
                poles = [(aux_pole, dest), (src, dest)]
                break