import math

def slices_to_meet_conditions(guests, condition):
    if condition == 1:
        return math.ceil(math.log(guests, 2))
    elif condition == 2:
        return math.ceil(math.log(2*guests, 2))
    elif condition == 3:
        return math.ceil(math.log(guests + 10, 2))


n = int(input("Введите количество гостей: "))

print("Для каждого из гостей получить хотя бы 1 кусок, необходимо", slices_to_meet_conditions(n, 1), "делений.")
print("Для того, чтобы как минимум половине гостей досталось по 2 куска, необходимо",
      slices_to_meet_conditions(n, 2), "делений.")
print("Для того, чтобы каждый гость получил хотя бы 1 кусок и осталось хотя бы 10 кусков в запасе, необходимо",
     slices_to_meet_conditions(n, 3), "делений.")
