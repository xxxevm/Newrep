def determine_loser(n, m):
    current_cubes = m
    player = 0
    cubes_to_take = 1
    while True:
        if cubes_to_take > 25:
            cubes_to_take = cubes_to_take - 25
        if cubes_to_take > current_cubes:
            return player + 1
        else:
            current_cubes -= cubes_to_take
        player = (player + 1) % n
        cubes_to_take *= 2

n = int(input("Введите количество детей: "))
m = int(input("Введите количество кубиков: "))

loser = determine_loser(n, m)
print("Проигравшим является ребёнок под номером:", loser)
