import math

def fibo_formula(n):
    return 1/2*(((1 + math.sqrt(5)) / 2) ** (n+1) - ((1 - math.sqrt(5)) / 2) ** (n+1) )

n = 2
while True:
    computed_value = fibo_formula(n)
    true_value = round(computed_value)
    difference = abs(computed_value - true_value)
    if difference > 0.001:
        break
    n += 1

print("Отличие превысило 0.001 начиная с n =", n)
