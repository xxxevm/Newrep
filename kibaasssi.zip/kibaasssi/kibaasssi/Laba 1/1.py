x = 2
print(x)
print(type(x))
x = x + 2
print(x)
print(type(x))
x = (x+1)/2
print(x)
print(type(x))
x = x + 1/2
print(x)
print(type(x))
x = (x < 5)
print(x)
print(type(x))
x = str(x)
print(x)
print(type(x))