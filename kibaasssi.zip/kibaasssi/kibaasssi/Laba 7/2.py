class Polynomial:
    def __init__(self, degree, coefficients):
        self.degree = degree
        self.coefficients = coefficients

    def evaluate(self, x):
        result = 0
        for i in range(self.degree + 1):
            result += self.coefficients[i] * (x ** i)
        return result

    def __add__(self, other):
        max_degree = max(self.degree, other.degree)
        sum_coefficients = [0] * (max_degree + 1)

        for i in range(max_degree + 1):
            if i <= self.degree:
                sum_coefficients[i] += self.coefficients[i]
            if i <= other.degree:
                sum_coefficients[i] += other.coefficients[i]

        return Polynomial(max_degree, sum_coefficients)

    def __sub__(self, other):
        max_degree = max(self.degree, other.degree)
        sub_coefficients = [0] * (max_degree + 1)

        for i in range(max_degree + 1):
            if i <= self.degree:
                sub_coefficients[i] += self.coefficients[i]
            if i <= other.degree:
                sub_coefficients[i] -= other.coefficients[i]

        return Polynomial(max_degree, sub_coefficients)

    def __mul__(self, other):
        mul_degree = self.degree + other.degree
        mul_coefficients = [0] * (mul_degree + 1)

        for i in range(self.degree + 1):
            for j in range(other.degree + 1):
                mul_coefficients[i + j] += self.coefficients[i] * other.coefficients[j]

        return Polynomial(mul_degree, mul_coefficients)

    def display_polynomial(self):
        poly_str = ""
        for i in range(self.degree, -1, -1):
            if self.coefficients[i] != 0:
                if i == self.degree:
                    poly_str += str(self.coefficients[i]) + "x^" + str(i)
                else:
                    poly_str += " + " + str(self.coefficients[i]) + "x^" + str(i)
        print(poly_str)

poly1 = Polynomial(3, [2, -1, 0, 4])
poly2 = Polynomial(2, [1, 0, -3])

print("Первый многочлен:")
poly1.display_polynomial()
print("\nВторой многочлен:")
poly2.display_polynomial()

x = 2
print("\nЗначение первого многочлена при x =", x, ":", poly1.evaluate(x))
print("Значение второго многочлена при x =", x, ":", poly2.evaluate(x))

print("\nСумма многочленов:")
(poly1 + poly2).display_polynomial()

print("\nРазность многочленов:")
(poly1 - poly2).display_polynomial()

print("\nПроизведение многочленов:")
(poly1 * poly2).display_polynomial()
