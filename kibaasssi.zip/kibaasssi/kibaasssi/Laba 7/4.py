class Train:
    def __init__(self, departure, destination, departure_time, arrival_time):
        self.departure = departure
        self.destination = destination
        self.departure_time = departure_time
        self.arrival_time = arrival_time

    def __add__(self, other):
        if self.destination == other.departure and self.arrival_time < other.departure_time:
            return Train(self.departure, other.destination, self.departure_time, other.arrival_time)
        else:
            print("Невозможно объединить поезда.")
            return None

    def __str__(self):
        return f"Поезд из {self.departure} в {self.destination}, отправление: {self.departure_time}, прибытие: {self.arrival_time}"

train1 = Train("Москва", "Санкт-Петербург", "12:00", "18:00")
train2 = Train("Санкт-Петербург", "Владивосток", "20:00", "10:00")

print("Первый поезд:", train1)
print("Второй поезд:", train2)

combined_train = train1 + train2
if combined_train:
    print("Объединенный поезд:", combined_train)


