import math
class Vector3D:
    def __init__(self, x1, y1, z1, x2, y2, z2):
        self.start = (x1, y1, z1)
        self.end = (x2, y2, z2)

    def __add__(self, other):
        x = self.end[0] - self.start[0] + other.end[0] - other.start[0]
        y = self.end[1] - self.start[1] + other.end[1] - other.start[1]
        z = self.end[2] - self.start[2] + other.end[2] - other.start[2]
        return Vector3D(0, 0, 0, x, y, z)

    def __sub__(self, other):
        x = self.end[0] - self.start[0] - (other.end[0] - other.start[0])
        y = self.end[1] - self.start[1] - (other.end[1] - other.start[1])
        z = self.end[2] - self.start[2] - (other.end[2] - other.start[2])
        return Vector3D(0, 0, 0, x, y, z)

    def dot_product(self, other):
        return (self.end[0] - self.start[0]) * (other.end[0] - other.start[0]) + \
               (self.end[1] - self.start[1]) * (other.end[1] - other.start[1]) + \
               (self.end[2] - self.start[2]) * (other.end[2] - other.start[2])

    def length(self):
        return math.sqrt((self.end[0] - self.start[0]) ** 2 +
                         (self.end[1] - self.start[1]) ** 2 +
                         (self.end[2] - self.start[2]) ** 2)

    def cosine_angle(self, other):
        dot_product = self.dot_product(other)
        self_length = self.length()
        other_length = other.length()
        return dot_product / (self_length * other_length)

# Пример использования класса
vector1 = Vector3D(0, 0, 0, 1, 2, 3)
vector2 = Vector3D(0, 0, 0, 4, 5, 6)

print("Вектор 1:", vector1.start, "-", vector1.end)
print("Вектор 2:", vector2.start, "-", vector2.end)

sum_vector = vector1 + vector2
dev_vector = vector1 - vector2
print("\nСумма векторов:", sum_vector.start, "-", sum_vector.end)
print("Разность векторов:", dev_vector.start, "-", dev_vector.end)

print("\nСкалярное произведение векторов:", vector1.dot_product(vector2))
print("Длина вектора 1:", vector1.length())
print("Длина вектора 2:", vector2.length())

cosine = vector1.cosine_angle(vector2)
print("Косинус угла между векторами:", cosine)
print("Угол между векторами в радианах:", math.acos(cosine))
print("Угол между векторами в градусах:", math.degrees(math.acos(cosine)))
