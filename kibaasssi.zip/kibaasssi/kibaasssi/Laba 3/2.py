x = int(input())
print((3*5 > 1) or x)
print((3*5 < 10) and x)