def getInput():
    s = input()
    return s

def testInput(s):
    try:
        int(s)
        return True
    except:
        return False

def strToInt(s):
    return int(s)

def printInt(s):
    print(s)

s = getInput()
if testInput(s):
    printInt(strToInt(s))