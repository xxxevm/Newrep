n = int(input())
for i in range(2, n + 1):
    if n % i == 0:
        print(i)
        break
i = 2
while i <= n:
    if n % i == 0:
        print(i)
        break
    i = i + 1